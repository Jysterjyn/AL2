#pragma once
enum Color
{
	WHITE, BLACK, RED, GREEN, BLUE
};

enum PressShake
{
	RANGE, INTERVAL
};

enum JumpCircle
{
	START_RADIUS, SPREAD_SPD
};

enum PlayerShapes
{
	BOX, CIRCLE
};

enum ParticleNum
{
	PALSE, CHANGE_SHAPE
};